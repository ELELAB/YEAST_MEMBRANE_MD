# LPMO

This folder contains some script that was used to setup and analyze a LPMO protein.

These were never used in any publication.
