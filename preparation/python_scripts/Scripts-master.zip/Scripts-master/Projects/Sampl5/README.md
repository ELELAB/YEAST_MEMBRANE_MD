# Sampl5

This folder contains scripts created while working on this paper:

Genheden S. & Essex JW, All-atom/coarse-grained hybrid predictions of distribution coefficients in SAMPL5. *J. Comput.-Aided Mol. Des.*, **2016**, *30*, 969-976
