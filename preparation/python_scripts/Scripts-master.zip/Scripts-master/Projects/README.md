# Project scripts

These folders contains scripts created for specific projects.

As such they are *less documented and less tested in various contexts than other codes*.

Extra caution is warranted.
