# Trehalose

This folder contains scripts created while working on a project on trehalose

These have not been used in any publication 
