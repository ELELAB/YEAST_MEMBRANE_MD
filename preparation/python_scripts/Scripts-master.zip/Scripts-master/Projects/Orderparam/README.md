# Orderparam

This folder contains scripts created while working on this paper:

Genheden S., Effect of solvent model when probing protein dynamics with molecular dynamics. *J. Mol. Graph. Model.*, **2017**, *71*, 80-87

For some scripts you need these libraries:
* prody
* encore
* openpyxl
