# GPCR

This folder contains scripts created while working on this paper:

Genheden S., Essex JW., Lee AG. G protein coupled receptor interactions with cholesterol deep in the membrane. *BBA Biomem.*, **2017**, *1859*, 268-281

How to use the analysis scripts can be found in `do_anal.bash`

Most of the library code is in `gpcr_lib.py`
