# Liposome

This folder contains scripts created while working on this paper:

Genheden S. & Eriksson LA, Estimation of Liposome Penetration Barriers of Drug Molecules with All-Atom and Coarse-Grained Models. *J. Chem. Theory Comput.*, **2016**, *12*, 4651-4661
