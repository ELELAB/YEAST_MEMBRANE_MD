# Yeast

This folder contains scripts created while working on this paper:

Lindal L., Genheden S., Faria-Oliveira F., Allard S., Eriksson LA., Olsson L., Bettiga M. Alcohols enhance the rate of acetic acid diffusion in S. cerevisiae: biophysical mechanisms and implications for acetic acid tolerance. *Microbial Cell*, **2018**, *5*, 42
