
Cython routines to perform common contact analysis on series of states
